text = input("Enter a title: ")

length = len(text)

print("The length of the title is ", length)
